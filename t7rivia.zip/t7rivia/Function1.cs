using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

public static class HttpTriggerFunction
{
    [FunctionName("HttpTriggerFunction")]
    public static IActionResult Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req)
    {
        // Lue HTTP POST -pyynn�n runko
        string requestBody = new StreamReader(req.Body).ReadToEnd();

        // Deserialisoi JSON-data
        dynamic data = JsonConvert.DeserializeObject(requestBody);

        // Lue JSON:n kent�t
        string name = data?.name;
        int a = data?.a ?? 0;
        int b = data?.b ?? 0;

        // Laske summa
        int sum = a + b;

        // Luo vastaus
        string responseMessage = $"[Oma Nimi]: Hei {name}. Lukujen {a} ja {b} summa on {sum}.";

        return new OkObjectResult(responseMessage);
    }
}